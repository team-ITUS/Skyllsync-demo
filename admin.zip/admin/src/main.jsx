import { createRoot } from "react-dom/client";
import LandingHome from "./LandingHome";
import "./index.css";

createRoot(document.getElementById("root")).render(<LandingHome />);
